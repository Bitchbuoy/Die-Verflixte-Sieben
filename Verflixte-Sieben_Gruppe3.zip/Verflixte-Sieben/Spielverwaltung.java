import javax.swing.JOptionPane;
/**
 * Beschreiben Sie hier die Klasse Spielverwaltung.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Spielverwaltung
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    private Spieler spieler1, spieler2;
    private Topf topf;
    private Wuerfel wuerfel1, wuerfel2;
    private String name1, name2;
    private boolean zugSpieler1, startSpieler1, gesetzt, soundAn, spiel;
    private int score1, score2;
    
    /**
     * Konstruktor für Objekte der Klasse Spielverwaltung
     */
    public Spielverwaltung()
    {
        // Instanzvariable initialisieren
        topf = new Topf();
        wuerfel1 = new Wuerfel();
        wuerfel2 = new Wuerfel();
        spieler1 = new Spieler(wuerfel1, wuerfel2, topf);
        spieler2 = new Spieler(wuerfel1, wuerfel2, topf);
        name1 = JOptionPane.showInputDialog("Name des ersten Spielers:");
        spieler1.setName(name1);
        name2 = JOptionPane.showInputDialog("Name des zweiten Spielers:");
        spieler2.setName(name1);
        startSpieler1 = true;
        zugSpieler1 = true;
        soundAn = false;
        spiel = true;
        try {
                spieleSound("/sounds/start.wav");
            } catch(Exception e){
                System.out.println("Der Sound geht nicht!");
            }
    }

    /**
     * Die Methode ruft die Metohde Wuerfeln() vom Spieler auf 
     * und addiert die gewürfelte Zahl zu seinem Score,
     * wenn eine "7" gewürfelt wird, wird getauscht auch bei zu vielen Würfen wird getauscht.
     * 
     * 
     * @return   Text für die GUI
     */
    public String wuerfeln()
    {
        String ausgabe = "";
        int tempPunkte;
        if (gesetzt == true){
            try {
                spieleSound("/sounds/wuerfeln.wav");
            } catch(Exception e){
                System.out.println("Der Sound geht nicht!");
            }
            if (zugSpieler1 == true){
                spieler1.wuerfeln();
                tempPunkte = spieler1.getPunkte();
                ausgabe = name1+ " hat eine "+ tempPunkte +" gewürfelt \n";
                if (tempPunkte == 7){
                    score1 -= 7;
                    ausgabe += name1+ " hat jetzt "+ score1 +" Punkte \n \n";
                    ausgabe += tauschen();
                } else if(spieler1.getWurfAnzahl() == spieler2.getWurfAnzahl()){
                    score1 += tempPunkte;
                    ausgabe += name1+ " hat jetzt "+ score1 +" Punkte \n \n";
                    ausgabe += tauschen();
                } else{
                    score1 += tempPunkte;
                    ausgabe += name1+ " hat jetzt "+ score1 +" Punkte \n \n";
                }
            } else{
                spieler2.wuerfeln();
                tempPunkte = spieler2.getPunkte();
                ausgabe = name2+ " hat eine "+ tempPunkte +" gewürfelt \n";
                if (tempPunkte == 7){
                    score2 -= 7;
                    ausgabe += name2+ " hat jetzt "+ score2 +" Punkte \n \n";
                    ausgabe += tauschen();
                } else if(spieler2.getWurfAnzahl() == spieler1.getWurfAnzahl()){
                    score2 += tempPunkte;
                    ausgabe += name2+ " hat jetzt "+ score2 +" Punkte \n \n";
                    ausgabe += tauschen();
                } else{
                    score2 += tempPunkte;
                    ausgabe += name2+ " hat jetzt "+ score2 +" Punkte \n \n";
                }
            }
        } else{
            ausgabe = "Bitte erst setzen! \n \n";
        }
        return ausgabe;
    }
    
    /**
     * Wenn Spieler1 dran ist, ist danach Spieler2 dran,
     * wenn bereits getauscht wurde ist die Runde zu Ende und es wird auswerten() aufgerufen.
     * 
     * 
     * @return   Text für die GUI
     */
    public String tauschen()
    {
        String string = "";
        if (startSpieler1 == true){
            if (zugSpieler1 == true){
                zugSpieler1 = false;
                string = name2 + " ist jetzt dran! \n \n";
            } else{
                startSpieler1 = false;
                string = auswerten() + "\n";
            }
        } else{
            if (zugSpieler1 == false){
                zugSpieler1 = true;
                string = name1 + " ist jetzt dran! \n \n";
            } else{
                startSpieler1 = true;
                string = auswerten() + "\n";
            }
        }
        return string;
    }
    
    /**
     * erst wird geprüft, ob beide Spieler genung Vermögen haben,
     * dann setzen beide ihren Einsatz.
     * 
     * 
     * @param   Einsatz
     * @return   Text für die GUI
     */
    public String setzen(int pEinsatz)
    {
        String string = "";
        if (gesetzt == false){
            if (pEinsatz <= spieler1.getVermoegen() && pEinsatz <= spieler2.getVermoegen()){
                spieler1.einsatzSetzen(pEinsatz);
                spieler2.einsatzSetzen(pEinsatz);
                gesetzt = true;
                string = "Der Einsatz beträgt " + pEinsatz + " Credit(s)\n";
                string += name1 + " hat jetzt noch " + spieler1.getVermoegen() + " Credit(s)\n";
                string += name2 + " hat jetzt noch " + spieler2.getVermoegen() + " Credit(s)\n" + "\n";
            } else{
                string = "Der Einsatz ist zu groß! \n";
                string += name1 + " hat noch " + spieler1.getVermoegen() + " Credit(s)\n";
                string += name2 + " hat noch " + spieler2.getVermoegen() + " Credit(s)\n \n";
            }
        } else{
            string = "Es wurde bereits gesetzt! \n \n";
        }
        //boolean spieler.kannSetzen(pEinsatz) muss noch erstellt werden. soll nur prüfen ob der Einsatz kleiner als das vermoegen ist.
        return string;
    }
    
    /**
     * Es wird geprüft, wer den höheren Score hat, der jenige hat gewonnen
     * und kriegt den Inhalt vom Topf.
     * 
     * 
     * @return   Text für die GUI
     */
    public String auswerten()
    {
        String string = "";
        try {
                spieleSound("/sounds/win.wav");
            } catch(Exception e){
                System.out.println("Der Sound geht nicht!");
            }
        if (score1 > score2){
            string = name1 + " hat gewonnen!(" + score1 +"/" + score2 + ") \n";
            spieler1.topfLeeren();
        } else if(score1 == score2){
            string = "Unentschieden! \n";
        } else if(score1 < score2){
            string = name2 + " hat gewonnen!(" + score1 +"/" + score2 + ") \n";
            spieler2.topfLeeren();
        }
        string += name1+ " hat jetzt "+ spieler1.getVermoegen() + " Credit(s)\n";
        string += name2+ " hat jetzt "+ spieler2.getVermoegen() + " Credit(s)\n";
        if (spieler1.getVermoegen() == 0){
            spiel = false;
            string += name1 + " hat keine Credits mehr. Das Spiel ist vorbei! \n";
        } else if (spieler2.getVermoegen() == 0){
            spiel = false;
            string += name2 + " hat keine Credits mehr. Das Spiel ist vorbei! \n";
        }
        score1 = 0;
        score2 = 0;
        spieler1.neueRunde();
        spieler2.neueRunde();
        gesetzt = false;
        return string;
    }
    
    /**
     * Es wird tauschen() aufgerufen, wenn der Spieler mindestens einmal gewürfelt hat.
     * 
     * 
     * @return   Text für die GUI
     */
    public String zugAbgeben()
    {
        String string = "";
        if (zugSpieler1 == true && spieler1.getWurfAnzahl() > 0){
            string = tauschen();
        } else if(zugSpieler1 == false && spieler2.getWurfAnzahl() > 0){
            string = tauschen();
        } else{
            string = "Du musst mindestens einmal Würfeln! \n \n";
        }
        return string;
    }
    
    /**
     * Es wird geprüft, wer mehr Vermögen hat, sein Vermögen ist dann der Einsatz.
     * 
     * 
     * @return   Text für die GUI
     */
    public String allIn()
    {
        String string = "";
        int pEinsatz;
        if (gesetzt == false){
            if (spieler1.getVermoegen() != 0 && spieler2.getVermoegen() != 0){
                if (spieler1.getVermoegen() <= spieler2.getVermoegen()){
                    pEinsatz = spieler1.getVermoegen();
                } else{
                    pEinsatz = spieler2.getVermoegen();
                }
                spieler1.einsatzSetzen(pEinsatz);
                spieler2.einsatzSetzen(pEinsatz);
                gesetzt = true;
                if (zugSpieler1 == true){
                    string = name1 + " geht All In! Der Einsatz beträgt " + pEinsatz + " Credit(s)\n";
                } else{
                    string = name2 + " geht All In! Der Einsatz beträgt " + pEinsatz + " Credit(s)\n";
                }
                string += name1 + " hat jetzt noch " + spieler1.getVermoegen() + " Credit(s)\n";
                string += name2 + " hat jetzt noch " + spieler2.getVermoegen() + " Credit(s)\n \n";
            } else{
                string = "Ein Spieler hat keine Credits mehr! \n \n";
            }
        } else{
            string = "Es wurde bereits gesetzt! \n \n";
        }
        return string;
    }
    
    /**
     * Es werden alle Werte wieder auf die Startwerte gesetzt,
     * das gleiche passiert bei den Spielern.
     * 
     * 
     * @return   Text für die GUI
     */
    public String neuStart()
    {
        score1 = 0;
        score2 = 0;
        startSpieler1 = true;
        zugSpieler1 = true;
        gesetzt = false;
        // void neuesSpiel() soll das vermoegen auf 100 setzen und die wurfAnzahl auf null.
        spieler1.neuesSpiel();
        spieler2.neuesSpiel();
        int temp = topf.einsatzAbgeben();
        return "Das Spiel wurde neu gestartet! \n \n";
    }
    
    /**
     * Die punkte des ersten Wuerfels werden für die GUI zurückgegeben.
     * 
     * 
     * @return   punkte Wuerfel1
     */
    public int getWuerfel1()
    {
        return wuerfel1.punkteAngeben();
    }
    
    /**
     * Die punkte des zweite Wuerfels werden für die GUI zurückgegeben.
     * 
     * 
     * @return   punkte Wuerfel2
     */
    public int getWuerfel2()
    {
        return wuerfel2.punkteAngeben();
    }
    
    /**
     * Der Sound wird an bzw aus geschaltet.
     * 
     * 
     */
    public void sound()
    {
        if (soundAn == true){
            soundAn = false;
        }else {
            soundAn = true;
        }
    }
    
    /**
     * Ein Sound wird über die Klasse Sound abgespielt.
     * 
     * 
     */
    public void spieleSound(String pSoundName)
    {
        if (soundAn){
            Sound neuerSound = new Sound();
            try {
                neuerSound.spieleSound(pSoundName);
            } catch(Exception e) {
                System.out.println("geht nicht!");
            }
        }
    }
}