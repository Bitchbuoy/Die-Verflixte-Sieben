import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
 
/**
 * Beschreiben Sie hier die Klasse GUI.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class GUI extends JFrame implements ActionListener
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    private JButton wuerfeln, allIn, einsatzSetzen, zugAbgeben, neuStart, switchMode, sound;
    private JTextArea textfeld; 
    private JTextField eingabeFeld;
    private boolean lightMode, soundAn;
    private JPanel panel, picturePanel, buttonPanel2, tempPanel;
    private Spielverwaltung spielv;
    
    /**
     * Konstruktor für Objekte der Klasse GUI.
     */
    public GUI()
    {
        spielv = new Spielverwaltung();
        soundAn = false;
        lightMode = false;
        createGUI();
    }
    
    /**
     * Main-Methode des Projekts.
     */
    public void main(String[] args) {
     GUI neueGUI = new GUI();
    }
    
    /**
     * Wenn ein Button gedrückt wird, wird die passende Metohde aufgerufen.
     */
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == this.wuerfeln) {
           addText(spielv.wuerfeln());
           wuerfelAnzeigen();
        } else if (e.getSource() == this.allIn){
            addText(spielv.allIn());
        } else if (e.getSource() == this.einsatzSetzen){
            addText(spielv.setzen(Integer.parseInt(eingabeFeld.getText())));
        }else if (e.getSource() == this.zugAbgeben) {
            addText(spielv.zugAbgeben());
        }else if (e.getSource() == this.neuStart) {
            neuStart();
            addText(spielv.neuStart());
        }else if (e.getSource() == this.switchMode) {
            switchMode();
        }else if (e.getSource() == this.sound) {
            spielv.sound();
            sound();
        }
    }
    
    /**
     * Der Text vom Button Sound wird geändert.
     */
    public void sound()
    {
        if (soundAn == true){
            soundAn = false;
            sound.setText("Sound An");
        } else{
            soundAn = true;
            sound.setText("Sound Aus");
        }
    }
    
    /**
     * Das Textfeld wird geleert.
     */
    public void neuStart()
    {
        textfeld.selectAll();
        textfeld.cut();
        textfeld.setText("Wilkommen beim Spiel Verflixte Sieben! \n \n");
    }
    
    /**
     * Das jeweils passende Wuerfel-Bild wird angezeigt.
     */
    public void wuerfelAnzeigen()
    {
        int wuerfel1;
        int wuerfel2;
        tempPanel.removeAll();
        picturePanel.removeAll();
        wuerfel1 = spielv.getWuerfel1();
        wuerfel2 = spielv.getWuerfel2();
        try {
            BufferedImage myPicture = ImageIO.read(new File("becher.png"));
            JLabel picLabel = new JLabel(new ImageIcon(myPicture));
            picturePanel.add(picLabel, BorderLayout.CENTER);
        } catch(Exception e) {
            
        }
        try {
            BufferedImage myPicture = ImageIO.read(new File(wuerfel1 + ".png"));
            JLabel picLabel = new JLabel(new ImageIcon(myPicture));
            tempPanel.add(picLabel);
            picturePanel.add(tempPanel, BorderLayout.PAGE_END);
        } catch(Exception e) {
            
        }
        try {
            BufferedImage myPicture = ImageIO.read(new File(wuerfel2 + ".png"));
            JLabel picLabel = new JLabel(new ImageIcon(myPicture));
            tempPanel.add(picLabel);
            picturePanel.add(tempPanel, BorderLayout.PAGE_END);
        } catch(Exception e) {
            
        }
        picturePanel.add(buttonPanel2, BorderLayout.PAGE_START);
        panel.add(picturePanel, BorderLayout.LINE_END);
        panel.updateUI();
    }
    
    /**
     * Die Farben der GUI werden geändert.
     */
    public void switchMode()
    {
         if (lightMode == false){
          lightMode = true;
          wuerfeln.setBackground(new Color( 255, 255, 255 ));
          wuerfeln.setForeground(new Color(0, 0, 0));
          einsatzSetzen.setBackground(new Color( 255, 255, 255 ));
          einsatzSetzen.setForeground(new Color(0, 0, 0));
          zugAbgeben.setBackground(new Color( 255, 255, 255 ));
          zugAbgeben.setForeground(new Color(0, 0, 0));
          allIn.setBackground(new Color( 255, 255, 255 ));
          allIn.setForeground(new Color(0, 0, 0));
          neuStart.setBackground(new Color( 255, 255, 255 ));
          neuStart.setForeground(new Color(0, 0, 0));
          switchMode.setBackground(new Color( 255, 255, 255 ));
          switchMode.setForeground(new Color(0, 0, 0));
          sound.setBackground(new Color( 255, 255, 255 ));
          sound.setForeground(new Color(0, 0, 0));
          textfeld.setBackground(new Color(255, 255, 255));
          textfeld.setForeground(new Color(0, 0, 0));
         }
         else {
          lightMode = false;  
          wuerfeln.setBackground(new Color( 90,102,106  ));
          wuerfeln.setForeground(new Color(221,200,34));
          einsatzSetzen.setBackground(new Color( 90,102,106 ));
          einsatzSetzen.setForeground(new Color(221,200,34));
          zugAbgeben.setBackground(new Color( 90,102,106  ));
          zugAbgeben.setForeground(new Color(221,200,34));
          allIn.setBackground(new Color( 90,102,106  ));
          allIn.setForeground(new Color(221,200,34));
          neuStart.setBackground(new Color( 90,102,106  ));
          neuStart.setForeground(new Color(221,200,34));
          switchMode.setBackground(new Color( 90,102,106  ));
          switchMode.setForeground(new Color(221,200,34));
          sound.setBackground(new Color( 90,102,106  ));
          sound.setForeground(new Color(221,200,34));
          textfeld.setBackground(new Color(110,122,126));
          textfeld.setForeground(new Color(221,200,34));
         }
    }
    
    /**
     * Die GUI wird erstellt.
     */
    public void createGUI()
    {
        JFrame meinJFrame = new JFrame();
      meinJFrame.setTitle("Verflixte Sieben");
      meinJFrame.setSize(1000, 600);
      panel = new JPanel();
      panel.setLayout(new BorderLayout());
      JPanel buttonPanel = new JPanel();
      buttonPanel.setLayout(new FlowLayout());
      picturePanel = new JPanel(new BorderLayout());
      buttonPanel2 = new JPanel(new BorderLayout());
      tempPanel = new JPanel();
      
      
      textfeld = new JTextArea(20,65);
      
      textfeld.setText("Wilkommen beim Spiel Verflixte Sieben! \n \n");
      
      textfeld.setLineWrap(true);
      
      textfeld.setWrapStyleWord(true);
      textfeld.setBackground(new Color(110,122,126));
      textfeld.setForeground(new Color(221,200,34));
      Font font = new Font("Casino", Font.PLAIN, 15);
      textfeld.setFont(font);
      
      JScrollPane scrollpane = new JScrollPane(textfeld);
      
      panel.add(scrollpane, BorderLayout.LINE_START);
      
      meinJFrame.add(panel);
      meinJFrame.setVisible(true);
      
      
     try {
         wuerfeln = new JButton(new ImageIcon(this.getClass().getResource("/images/buttonWuerfeln.png")));
     } catch(Exception e) {
         wuerfeln = new JButton("Würfeln");
     }
     try {
         einsatzSetzen = new JButton (new ImageIcon(this.getClass().getResource("/images/buttonEinsatzSetzen.png")));
     } catch(Exception e) {
         einsatzSetzen = new JButton("Einsatz setzen");
     }
     try {
         zugAbgeben = new JButton(new ImageIcon(this.getClass().getResource("/images/buttonSpielzugBeenden.png")));
     } catch(Exception e) {
         zugAbgeben = new JButton("Zug abgeben");
     }
     try {
         allIn = new JButton(new ImageIcon(this.getClass().getResource("/images/buttonAllIn.png")));
     } catch(Exception e) {
         allIn = new JButton("AllIn");
     }
     try {
         neuStart = new JButton(new ImageIcon(this.getClass().getResource("/images/buttonNeuStart.png")));
     } catch(Exception e) {
         neuStart = new JButton("Neu Start");
     }
     
      switchMode = new JButton("Switch Mode");
      sound = new JButton("Sound An");
      
      wuerfeln.addActionListener(this);
      einsatzSetzen.addActionListener(this);
      zugAbgeben.addActionListener(this);
      allIn.addActionListener(this);
      neuStart.addActionListener(this);
      switchMode.addActionListener(this);
      sound.addActionListener(this);
      eingabeFeld = new JTextField();
      eingabeFeld.setColumns(10);
      
      buttonPanel.add(eingabeFeld);
      buttonPanel.add(einsatzSetzen);
      buttonPanel.add(allIn);
      buttonPanel.add(wuerfeln);
      buttonPanel.add(zugAbgeben);
      buttonPanel.add(neuStart);
      buttonPanel2.add(switchMode,BorderLayout.PAGE_START);
      buttonPanel2.add(sound,BorderLayout.CENTER);
      
      picturePanel.add(buttonPanel2, BorderLayout.PAGE_START);
      
      buttonPanel.setBackground(new Color(140,152,156));
      buttonPanel.setForeground(Color.white);
      
      Font buttonFont = new Font("Reem Kufi", Font.PLAIN, 10);
      wuerfeln.setFont(buttonFont);
      einsatzSetzen.setFont(buttonFont);
      zugAbgeben.setFont(buttonFont);
      allIn.setFont(buttonFont);
      neuStart.setFont(buttonFont);
      switchMode.setFont(buttonFont);
      sound.setFont(buttonFont);
      
      wuerfeln.setBackground(new Color( 90,102,106  ));
      wuerfeln.setForeground(new Color(221,200,34));
      einsatzSetzen.setBackground(new Color( 90,102,106  ));
      einsatzSetzen.setForeground(new Color(221,200,34));
      zugAbgeben.setBackground(new Color( 90,102,106 ));
      zugAbgeben.setForeground(new Color(221,200,34));
      allIn.setBackground(new Color(90,102,106  ));
      allIn.setForeground(new Color(221,200,34));
      neuStart.setBackground(new Color(90,102,106 ));
      neuStart.setForeground(new Color(221,200,34));
      switchMode.setBackground(new Color(90,102,106 ));
      switchMode.setForeground(new Color(221,200,34));
      sound.setBackground(new Color(90,102,106 ));
      sound.setForeground(new Color(221,200,34));
      
      panel.setBackground(new Color(140,152,156));
      picturePanel.setBackground(new Color(140,152,156));
      tempPanel.setBackground(new Color(140,152,156));
      
      panel.add(picturePanel, BorderLayout.LINE_END);
      panel.add(buttonPanel, BorderLayout.PAGE_END);
      try {
         BufferedImage myPicture = ImageIO.read(new File("becher.png"));
         JLabel picLabel = new JLabel(new ImageIcon(myPicture));
         picturePanel.add(picLabel);
     } catch(Exception e) {
         
     }
    }
    
    /**
     * Der Text wird zum Textfeld hinzugefügt.
     * 
     * @param auszugebender Text
     */
    public void addText(String newText) {
      textfeld.append(newText);
    }
}

